const fs = require('fs');
const jsonAutos = fs.readFileSync(__dirname + '/autos.json', 'UTF-8');
const autos = JSON.parse(jsonAutos)

console.log('==== Consigna 1 ====');
console.log('Autos json:', autos);

const carrera = {
    autos,
    autosPorTanda: 5, // Cantidad maxima de autos por tanda
    autosHabilitados() {
        return this.autos.filter(auto => !auto.sancionado);
    },
    listarAutos(listaAutos) {
        listaAutos.forEach(auto => {
            const textoPatente = `Patente: ${auto.patente}`;
            const textoPeso = `peso en kg: ${auto.patente}`;
            const textoPiloto = `piloto: ${auto.piloto}`;
            const textoEstado = `estado: ${auto.sancionado ? 'sancionado' : 'puede correr'}`;
            
            console.log(`${textoPatente}, ${textoPeso}, ${textoPiloto}, ${textoEstado}`);
        });
    },
    buscarPorPatente(patente) {
        return this.autos.find(auto => auto.patente === patente)
    },
    buscarPorCilindrada(cilindrada) {
        return this.autosHabilitados().filter(auto => auto.cilindrada === cilindrada);
    },
    orderarPorVelocidad() {
        return this.autos.sort((a, b) => {
            if ( a.velocidad < b.velocidad ) return -1;
            if ( a.velocidad > b.velocidad ) return 1;
            return 0;
        });
    },
    generarTanda(cilindradaMaxima, pesoMaximo) {
        /**
         * Recorro los autos habilitados filtradolos por cilindradaMaxima y pesoMaximo
         * y corto el array para obtener maximo la cantidad de autos por tanda
         * */
        return this.autosHabilitados().filter(auto => auto.cilindrada <= cilindradaMaxima && auto.peso <= pesoMaximo).slice(0, this.autosPorTanda);
    },
    calcularPodio(autosTandaActual) {
        // Ordeno los autos de la tanda generada de mayor a menor puntaje y obtengo los tres primeros
        const [auto1, auto2, auto3] = autosTandaActual.sort((a, b) => {
            if ( a.puntaje < b.puntaje ) return 1;
            if ( a.puntaje > b.puntaje ) return -1;
            return 0;
        }).slice(0, 3);

        const crearTextoGanador = (auto) => {
            return `${auto.piloto}, con un puntaje de: ${auto.puntaje}`
        }
  
        let result = '';

        if(auto1) {
            result += `El ganador es: ${crearTextoGanador(auto1)};`
        }

        if(auto2) {
            result += ` el segundo puesto es para: ${crearTextoGanador(auto2)}`
        }

        if(auto3) {
            result += ` y el tercer puesto es para: ${crearTextoGanador(auto3)}`
        }

        if(!result) {
            console.log('No hay ganador');
        } else {
            console.log(result);
        }
        
       
    }
}


console.log('==== Consigna 2 ====');

console.log('C. Autos habilitados');
console.log(carrera.autosHabilitados());

console.log('D. Lista de autos');
carrera.listarAutos(autos);

console.log('E. Buscar por patente');
console.log(carrera.buscarPorPatente('JQK433'));

console.log('F. Buscar por cilindrada');
console.log(carrera.buscarPorCilindrada(1500)); 

console.log('G. Ordenar por velocidad');
console.log(carrera.orderarPorVelocidad()); 

console.log('H. Generar tanda y I. Calcular podio');
const tandaGenerada = carrera.generarTanda(2000, 4000);
console.log('Tanda Generada:', tandaGenerada);
carrera.calcularPodio(tandaGenerada);